export const environment = {
  apiBaseUrl: 'http://localhost:9097/',
};
