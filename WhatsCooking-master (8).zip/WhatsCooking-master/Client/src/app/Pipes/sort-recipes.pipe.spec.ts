import { SortRecipesPipe } from './sort-recipes.pipe';

describe('SortRecipesPipe', () => {
  it('create an instance', () => {
    const pipe = new SortRecipesPipe();
    expect(pipe).toBeTruthy();
  });
});
