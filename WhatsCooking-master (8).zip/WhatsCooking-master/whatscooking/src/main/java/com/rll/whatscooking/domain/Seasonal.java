package com.rll.whatscooking.domain;

public enum Seasonal {
    WINTER,
    SPRING,
    SUMMER,
    FALL
}