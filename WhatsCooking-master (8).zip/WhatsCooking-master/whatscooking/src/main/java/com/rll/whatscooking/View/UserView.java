package com.rll.whatscooking.View;

import lombok.Data;

@Data
public class UserView {

    int userId;
    String username;
    String firstName;
    String lastName;
    String role;
    String email;
}
