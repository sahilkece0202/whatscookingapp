package com.rll.whatscooking.domain;

public enum MealType {
    VEGETARIAN,
    NON_VEGETARIAN,
    VEGAN,
    PESCATARIAN,
    GLUTEN_FREE,
    DAIRY_FREE,
    KETO,
    PALEO
}