package com.rll.whatscooking.domain;

public enum Cuisine {
    ITALIAN,
    CHINESE,
    MEXICAN,
    INDIAN,
    FRENCH,
    JAPANESE,
    THAI,
    MEDITERRANEAN
}