package com.rll.whatscooking.domain;

public enum MealTiming {
    BREAKFAST,
    LUNCH,
    DINNER,
    SNACK,
    Drinks,
    Dessert
}